export interface RoutesArray {
  name: string;
  route: string;
  svg: string;
}
