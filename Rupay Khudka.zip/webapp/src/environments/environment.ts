  export const environment = {
    production: false,
    apiUrl: "http://localhost:3000",
    
    RupyaToken: "0x84eA74d481Ee0A5332c457a4d796187F6Ba67fEB",
    USDCToken: "0x9E545E3C0baAB3E08CdfD552C960A1050f373042",
    USDCXToken:" 0xa82fF9aFd8f496c3d6ac40E2a0F282E47488CFc9",
    RupyaXToken:"0x1613beB3B2C4f22Ee086B2b38C1476A3cE7f78E8",
    Lend: "0x851356ae760d987E095750cCeb3bC6014560891C",
    LendBorrow: "0xf5059a5D33d5853360D16C683c16e67980206f36",
    Stake: "0x95401dc811bb5740090279Ba06cfA8fcF6113778",
    User: "0x70e0bA845a1A0F2DA3359C97E0285013525FFC49",
    SimpleStorage: "0x998abeb3E57409262aE5b751f60747921B33613E",
    
    // IPFS Configuration
    ipfsURL: "https://ipfs.infura.io:5001",
    ipfsProjectID: "your-infura-project-id",
    ipfsProjectSecret: "your-infura-project-secret"
  };
    