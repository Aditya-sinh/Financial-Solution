import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wallet-connect',
  templateUrl: './wallet-connect.component.html',
  styleUrls: ['./wallet-connect.component.css'],
})
export class WalletConnectComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  login() {}
}
